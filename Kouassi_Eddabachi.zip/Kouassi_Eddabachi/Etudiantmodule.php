<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="Etudiantmodule.css">
</head>
<body>
    <div class="header">
        <div class="logo">
            <img src=C:\Users\yedda\Downloads\Groupe-Nolan-SAE-203-main\Groupe-Nolan-SAE-203-main\SAe203\Etudian alt="Logo" class="logo-img">
        </div>
       
    </div>
    <div class="container">
        <div class="Bienvenue">
            <input type="text" class="Recherche" placeholder="Rechercher">  
            <h1>Bonjour,</h1>
            <h2>Vue ensemble des Modules</h2> 
      
        </div>
        <div class="modules">
            <div class="module">
                <div class="module1"></div>
            </div>
            <div class="module">
                <div class="module1"></div>
            </div>
            <div class="module">
                <div class="module1"></div>
            </div>
            <div class="module">
                <div class="module1"></div>
            </div>
            <div class="module">
                <div class="module1"></div>
            </div>
            <div class="module">
                <div class="module1"></div>
            </div>
        </div>
    </div>
    
</body>
</html>